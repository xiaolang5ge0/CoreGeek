"""编排器：P1 —— Day1 Bootstrap（3火箭+FRONT/FLANK墙）+ 单人夜防 + 夜间采矿。

每回合数据流：
Turn 解析 → 反馈学习(BuildableMap) → 布局(动态FRONT) →
白天：建造分配 + WorkerFSM + 开拓者归位 / 黑夜：开拓者控炮 + 工人采矿 →
LegalityGuard 过滤 → 响应
"""
from __future__ import annotations

from typing import Any

from .buildable_map import BuildableMap
from .fire import JointFirePlanner
from .fsm_imp import ImpFSM
from .fsm_pioneer import (
    STATE_GUARD,
    STATE_TASK_ACCEPT,
    STATE_TASK_TRAVEL,
    STATE_TASK_WAIT_ACCEPT,
    STATE_TASK_WORK,
    PioneerFSM,
)
from .fsm_worker import ROLE_MINER, ROLE_REPAIRER, STONE_BATCH, WorkerFSM
from .path import next_step, step_toward
from .phases import PhaseManager
from .planners.layout import BaseLayout, choose_front, compute_layout
from .planners.news import NewsEconomy
from .planners.task import ST_CONFIRM, TaskPlanner, TaskSession
from .planners.treasure import TreasurePlanner, offerings_from_shop, zones_text
from .planners.upgrade import WALL_MAX_HP, UpgradePlanner
from .protocol import (
    IMP,
    MINE_TYPES,
    Pos,
    ROCKET,
    ROUNDS_PER_DAY,
    TOWER_TYPES,
    Turn,
    WALL,
    WEAPON_BUILD_COST,
    WEAPON_LIMIT,
    build_response,
    catch_command,
    distance,
    empty_response,
    move_command,
    parse_targets,
    station_footprint,
    use_command,
)
from .rules import LegalityGuard
from .threat import SAFE, ThreatEstimator
from .wall_registry import WallRegistry

NIGHT_SAFE_DIST = 3         # 夜间矿/小贩安全半径（机器人攻击射程3；主攻基地不绕路杀工人）
SPAWN_AVOID_DIST = 4        # 历史出生点直接避让半径
CORRIDOR_WIDTH = 5          # 机器人行军走廊半宽（出生点→我方基地连线附近）——B 方案安全矿定义
CORRIDOR_BASE_MARGIN = 8    # 走廊只算距基地 > 此值 的部分（近基地处有墙/炮塔保护，不算危险）
BASE_DANGER_DIST = 4        # 机器人逼近基地此距离内 → 基地有危险（工人撤内圈而非迎面避让）
WORKER_DANGER_DIST = 3      # 工人规避半径（≈机器人攻击射程）
BUILD_TRAVEL_BUFFER = 6     # 建墙预留回程缓冲（预留回合 = 待建墙数 + 缓冲）
DUSK_AVOID_WINDOW = 12      # 白天临近入夜此回合数内，提前避开出生走廊矿/小贩
COST_PER_WALL_BASE = 2      # 每墙基础回合（采集1+建造1）
WALL_ROUNDS_PER = 5         # 单工人每墙约需回合（采集+建造+挪位）；用于判断是否需第二工人帮建
REPAIR_MARGIN = 3           # 修理工提前归位余量（距天黑 ≤ 路径 + 3）
WEAPON_L1_COST = 100        # 武器 L1→L2 券价（判断是否需要凑武器升级费）
WEAPON_L2_COST = 150        # 武器 L2→L3 券价（用户 2026-09-23：D4 前 3 门 L3）
RESERVE_GOLD = 30           # 升级预算保留金
LLM_DAILY_LIMIT = 3         # 每日 LLM 调用上限（用户：每天只有 3 次）
WALL_DANGER_RATIO = 0.8     # 城墙危险阈值：预计伤害 > 城墙总HP × 此值 → 危险
DAY1_RUSH_DEADLINE = 50     # Day1 双工人建墙冲刺截止回合（预留收尾）
TASK_STALL_LIMIT = 12       # P1-A：TASK_WORK 超此回合数无 LLM 推进 → 放弃任务（防站到超时）
DAY1_WALL_TARGET = 12       # Day1 目标墙数
PIONEER_FLEE_DIST = 1       # 机器人贴到 CP 才撤离（过早撤离=整夜哑火，实战权衡）


class _Ctx:
    """单回合执行上下文：移动预留 + 决策痕迹。"""

    def __init__(self, trace: dict[str, Any]):
        self.trace = trace
        self.reserved: set = set()
        self.fsms: dict[int, WorkerFSM] = {}
        self.threat_level: str = SAFE
        self.home_anchor = None
        self.mine_blacklist: dict = {}
        self._recall_cells: dict[int, Any] = {}
        self.trace.setdefault("workers", {})

    def recall_cell(self, unit_id: int):
        return self._recall_cells.get(unit_id)

    def is_mine_blocked(self, pos, round_no: int) -> bool:
        """矿黑名单（新闻封矿/采集失败/采集死循环）：解封回合前回避。"""
        release = self.mine_blacklist.get(pos)
        return release is not None and round_no < release

    def block_mine(self, pos, release_round: int) -> None:
        self.mine_blacklist[pos] = release_round

    # 以下由 brain 每回合注入
    danger_workers: set = set()
    safe_anchor = None
    repair_worker: int | None = None
    share_mines: bool = False
    robot_cells: tuple = ()
    spawn_cells: tuple = ()   # 历史夜间出生点（全局固定，首夜起累积）
    imp_mine_ban: dict = {}   # IKKDR0-Q4：敌 imp 破坏 → 矿种禁采表（brain 注入）
    tasks_exhausted: bool = False  # IKKDR0-Q5-E：平台任务投放枯竭（brain 注入）
    corridor_cells: tuple = ()  # 出生点→我方基地 的行军走廊采样格（B 方案）
    base_in_danger: bool = False  # 机器人逼近基地 → 工人撤内圈；否则直接避让
    dusk_avoid: bool = False  # 夜间 或 白天临近入夜 → 提前避开出生走廊
    walls_left: int = 0       # 剩余待建墙数（石料岗按此收敛采集量，防过量）
    repair_triggered: bool = False   # 修理工夜间/临近天黑归位触发
    wall_danger: bool = False        # 城墙危险（问题4：预计伤害超阈值）
    night_now: bool = False          # 当前是否夜间（影响 mine_unsafe）
    need_weapon_gold: bool = False   # 有武器未 L2 且金不足 → 挖矿工去卖钱
    weapon_need_l2: bool = False     # 有武器未 L2 → 购买墙券/修复包时预留金币
    gunner_upgrade = None            # 炮手武器升级计划 (Pos, "weapon")
    price_boost_map: dict = {}       # 新闻预测：矿种 → 售卖加权
    wall_registry = None             # L2 围墙状态表（跨回合，供修理工按需修复/升级）
    treasure = None                  # 宝藏计划（民间传闻推断）
    repair_anchor = None             # 修理工夜间就位点（layout.repair_post，内圈邻墙）
    layout_front: str | None = None  # 布局开口侧（front），供墙目标等级计算
    layout_anchor = None             # 布局锚点 (station.x, station.y-1)，供墙目标等级计算
    miner_avoid = frozenset()        # 矿工夜间绕行格（机器人走廊；用户 2026-09-23）
    turret_cells: tuple = ()         # 炮塔格（CP 不可达时退到"邻接炮塔最多"的格；IKI60Z）
    prompt: str = ""                 # LLM prompt（非任务期 news/treasure 或任务）
    execute_cmd: str = ""            # 沙盒命令（仅任务期）

    def price_boost(self, kind: str) -> float:
        return float(self.price_boost_map.get(kind, 0.0))

    def mine_unsafe(self, pos) -> bool:
        """位置是否危险：活机器人近旁（昼夜都算）；走廊/出生点仅**白天黄昏窗口**算。
        夜间走廊改由**路径绕行**处理（`miner_avoid`），不把走廊矿点判为不可采（用户 2026-09-23）。"""
        from .protocol import distance as _d
        if any(_d(pos, rc) <= NIGHT_SAFE_DIST for rc in self.robot_cells):
            return True
        if getattr(self, "night_now", False):
            return False  # 夜间：走廊靠绕行，只看活机器人
        if any(_d(pos, sc) <= SPAWN_AVOID_DIST for sc in self.spawn_cells):
            return True
        return any(_d(pos, cc) <= CORRIDOR_WIDTH for cc in self.corridor_cells)

    def note(self, unit_id: int, msg: str) -> None:
        self.trace["workers"].setdefault(str(unit_id), {}).setdefault("notes", []).append(msg)

    def note_pioneer(self, msg: str) -> None:
        self.trace.setdefault("pioneer", {}).setdefault("notes", []).append(msg)

    def reserve_from(self, cmd: dict[str, Any] | None) -> None:
        if cmd and cmd.get("action") == "move":
            targets = parse_targets(cmd.get("targetPos"))
            if targets:
                self.reserved.add(targets[0])

    def other_mine_locks(self, unit_id: int) -> set:
        return {
            fsm.mine
            for uid, fsm in self.fsms.items()
            if uid != unit_id and fsm.mine is not None
        }


class Brain:
    def __init__(self) -> None:
        self.buildable = BuildableMap()
        self.fire = JointFirePlanner()
        self.phases = PhaseManager()
        self.threat = ThreatEstimator()
        self.upgrades = UpgradePlanner()
        self.pioneer_fsm = PioneerFSM()
        self.imp_fsm = ImpFSM()
        self.task_planner = TaskPlanner()
        self.task_session = TaskSession()
        self.mine_blacklist: dict = {}
        self.robot_spawn_log: list = []
        self.news_log: list = []  # 每回合 worldNews 存档（宝藏推断用）
        self.news_economy = NewsEconomy()
        self.treasure = TreasurePlanner()
        self._llm_waiting: str = ""      # 非任务期 LLM 用途：news / treasure
        self.llm_owner: str = ""         # P0-3：llmResp 通道归属（task/news/treasure），随 prompt 设置更新
        self._llm_round: int = 0
        self.wall_registry = WallRegistry()
        self.llm_day: int = 0
        self.llm_calls_today: int = 0
        self._boss_used_day: int = -1  # IKKIBC-Q6：BOSS 召唤令当日已用（防同日重复 use）
        self.llm_ban_day: int = -1   # errorCode=5（LLM 超限）当日封禁非任务 LLM（防连续超限堆异常，U18 保守口径）
        self.imp_mine_ban: dict[str, int] = {}  # IKKDR0-Q4：敌 imp 破坏 → 矿种禁采至解禁回合
        self.tasks_exhausted: bool = False      # IKKDR0-Q5-E：平台任务投放枯竭（F16）
        self._task_work_since: int | None = None  # P1-A：TASK_WORK 最近一次 LLM 推进的回合
        self._tasks_dead_since: int = 0         # 两任务点同时失效的起始回合
        self._layout_recomputed_round: int = -100  # 上次布局自愈重算回合
        self.worker_fsms: dict[int, WorkerFSM] = {}
        self.layout: BaseLayout | None = None
        self.front: str | None = None
        self.last_commands: dict[int, dict[str, Any]] = {}
        self.last_turn: Turn | None = None

    # ---- 主入口 ----
    def decide(self, payload: dict[str, Any] | None) -> tuple[dict[str, Any], dict[str, Any]]:
        """异常红线兜底：任何内部异常都回落合法空响应（5 次异常=判负）。"""
        try:
            return self._decide_core(payload)
        except Exception as exc:  # noqa: BLE001
            return empty_response(), {"fatal": f"decide:{exc!r}"}

    def _safe_unit(self, fn, trace: dict, tag: str, *args):
        """单单位决策异常隔离（2026-09-24）：某单位 FSM 崩溃不应让整队空转（0 指令=全线停摆）。

        异常记录到 trace["unit_errors"]，该单位本回合无指令（其他单位照常行动）。
        """
        try:
            return fn(*args)
        except Exception as exc:  # noqa: BLE001
            trace.setdefault("unit_errors", []).append(f"{tag}:{exc!r}")
            return None

    def _decide_core(self, payload: dict[str, Any] | None) -> tuple[dict[str, Any], dict[str, Any]]:
        trace: dict[str, Any] = {"code_phase": "P1"}
        if not isinstance(payload, dict):
            trace["fatal"] = "payload_not_dict"
            return empty_response(), trace
        try:
            turn = Turn.load(payload)
        except Exception as exc:
            trace["fatal"] = f"turn_load:{exc!r}"
            return empty_response(), trace

        self._learn(turn, trace)
        # 寻宝召唤结果处理（§8.4 + P1-6）：1/4 完成；2=地点错换点重推；3=祭品错保留地点；
        # 0=召唤未真正执行 → 仅在"已发出 summon 待结账"时消费（结果码常态 0 = 未发 summon）
        if turn.last_summon_result or self.treasure.take_await():
            self.treasure.on_summon_result(turn.last_summon_result)
            trace["summon_result"] = turn.last_summon_result
        # 非任务期 LLM 兜底：回收上回合响应（news / treasure），无响应 2 回合后放弃
        if self._llm_waiting and (
            turn.llm_resp or turn.round_no - self._llm_round >= 2
        ):
            if turn.llm_resp and self.llm_owner != self._llm_waiting:
                # P0-3 保险②：llmResp 通道归属与等待方不符（任务 prompt 抢占过通道），
                # 该响应绝不喂给 news/treasure（F8：任务会话读到宝藏 JSON 的根因）；
                # 本次提问作废，待下批线索重推。
                trace["llm_owner_mismatch"] = {
                    "waiting": self._llm_waiting, "owner": self.llm_owner,
                }
                self._llm_waiting = ""
            else:
                if turn.llm_resp:
                    if self._llm_waiting == "news":
                        if self.news_economy.apply_llm(turn.llm_resp):
                            trace["news_llm_applied"] = True
                    elif self._llm_waiting == "treasure":
                        # 记录 LLM 原文（用户 2026-09-23：便于定位宝藏链为何没落地；2026-09-24 加长以容纳 reason）
                        trace["treasure_llm_resp"] = str(turn.llm_resp)[:900]
                        if self.treasure.apply_llm(
                            turn.llm_resp, turn.day_index,
                            offerings=offerings_from_shop(turn.shop_prices),
                        ):
                            trace["treasure_llm_applied"] = True
                        else:
                            trace["treasure_llm_reject"] = {
                                "ready": self.treasure.plan.ready,
                                "location": (
                                    self.treasure.plan.location.dump()
                                    if self.treasure.plan.location else None
                                ),
                                "items": list(self.treasure.plan.items),
                                "day": self.treasure.plan.day,
                            }
                self._llm_waiting = ""
        if turn.station() is not None:
            if self.layout is None:
                self.front = choose_front(turn)
                self.layout = compute_layout(turn, self.front, self.buildable)
                if self.layout is not None:
                    trace["layout"] = {
                        "front": self.front,
                        "turrets": [p.dump() for p in self.layout.turret_cells],
                        "cp": self.layout.control_point.dump(),
                        "walls": len(self.layout.wall_cells),
                    }
                    # IKKIBC-Q5：开口朝向注入火力规划（后方 BOSS 判定）
                    self.fire.set_front(self.front, turn.station().pos if turn.station() else None)
            # 围墙缺口自愈（issue#26）：建造失败格 40 回合过期后可重建；
            # 布局缓存不会自动收回该格 → 白天定期重算布局，把恢复可用的墙格补回墙环。
            if (
                self.layout is not None
                and turn.is_day
                and turn.round_no - self._layout_recomputed_round >= 20
            ):
                recomputed = compute_layout(turn, self.front, self.buildable)
                if recomputed is not None and len(recomputed.wall_cells) > len(self.layout.wall_cells):
                    self.layout = recomputed
                    self._layout_recomputed_round = turn.round_no
                    trace["layout_gap_recovered"] = len(recomputed.wall_cells)
                    self.fire.set_front(self.front, turn.station().pos if turn.station() else None)
            # 围墙状态表刷新（识别攻破/补建，供修理工按需修复/升级）
            if self.layout is not None:
                self.wall_registry.sync(turn, self.layout)
                rebuilt = [
                    s for s in self.wall_registry.recently_rebuilt()
                    if turn.round_no - s.rebuilt_round <= ROUNDS_PER_DAY
                ]
                if rebuilt:
                    trace["walls_rebuilt"] = [s.pos.dump() for s in rebuilt]

        commands: dict[int, dict[str, Any]] = {}
        ctx = _Ctx(trace)
        ctx.fsms = self.worker_fsms
        ctx.wall_registry = self.wall_registry
        ctx.treasure = self.treasure
        ctx.layout_front = self.front
        _st = turn.station()
        ctx.layout_anchor = (_st.pos.x, _st.pos.y - 1) if _st is not None else None
        ctx.reserved = {u.pos for u in turn.controllable()}
        _imp0 = turn.imp()
        if _imp0 is not None:
            ctx.reserved.add(_imp0.pos)
        ctx.mine_blacklist = self.mine_blacklist
        ctx.imp_mine_ban = self.imp_mine_ban   # IKKDR0-Q4：敌 imp 破坏 → 矿种禁采
        ctx.tasks_exhausted = self.tasks_exhausted  # IKKDR0-Q5-E：任务枯竭 → 开拓者转产
        # 历史出生走廊（首夜起累积，全局固定）→ 夜间选矿/卖货避让
        ctx.spawn_cells = tuple(
            Pos(x, y) for entry in self.robot_spawn_log for (x, y) in entry["spawns"]
        )
        # B 方案安全矿定义：出生点→我方基地的行军走廊
        ctx.corridor_cells = self._corridor_cells(turn)
        # 矿工夜间绕行：机器人走廊（矩形）格（用户 2026-09-23）
        ctx.miner_avoid = (
            frozenset(ctx.corridor_cells) if turn.is_night else frozenset()
        )
        # 白天临近入夜也提前避开出生走廊（用户要求：接近晚上时避开历史出生位置）
        ctx.dusk_avoid = turn.is_night or (0 < turn.rounds_until_night <= DUSK_AVOID_WINDOW)
        ctx.night_now = turn.is_night
        ctx.prompt = ""
        ctx.execute_cmd = ""
        # errorCode=5（LLM 超限）→ 当日封禁非任务 LLM（防连续超限堆异常，U18 保守口径）
        if any(code == 5 for code, _ in turn.errors) and self.llm_ban_day != turn.day_index:
            self.llm_ban_day = turn.day_index
            trace["llm_ban"] = {"day": turn.day_index, "round": turn.round_no}
        self._record_news(turn, ctx)      # 可能设置 ctx.prompt（news/宝藏 LLM 提问）
        ctx.price_boost_map = self.news_economy.boosts(turn.day_index)
        if turn.is_day:
            self._day(turn, commands, ctx)
        else:
            self._night(turn, commands, ctx)
        # 32进16：捣乱鬼决策 + 全队反抓防御（敌 imp 仅站桩破坏时可见 → 可见即正在破坏）
        self._imp_and_catch_defense(turn, commands, ctx)

        commands = LegalityGuard(turn).filter_commands(commands, trace)
        self.last_commands = dict(commands)
        self.last_turn = turn
        trace.update(day=turn.day_index, is_day=turn.is_day, gold=turn.gold)
        return build_response(commands, prompt=ctx.prompt, execute_cmd=ctx.execute_cmd), trace

    # ---- 反馈学习 ----
    def _learn_tasks_exhausted(self, turn: Turn, trace: dict[str, Any]) -> None:
        """IKKDR0-Q5-E（F16 定案）：平台任务投放会枯竭——任务点冷却归 0 但 isValid
        恒 false、奖励归 0（IKKDR0 实锤：D4 中午后全场无任务）。
        检测：两任务点全部 (not is_valid and coldDownRounds==0) 持续 >30 回合 → 枯竭，
        开拓者转产（宝藏主线优先，不再 GUARD 蹲守）。出现任何有效任务即复位。
        """
        live = any(t.is_valid or t.cooldown_rounds > 0 for t in turn.tasks)
        if not turn.tasks:
            return  # 任务数据缺失 → 不判定（平台偶发不下发，避免误判/误复位）
        if live:
            if self.tasks_exhausted:
                trace["tasks_revived"] = True
            self.tasks_exhausted = False
            self._tasks_dead_since = 0
            return
        if self._tasks_dead_since == 0:
            self._tasks_dead_since = turn.round_no
        if not self.tasks_exhausted and turn.round_no - self._tasks_dead_since > 30:
            self.tasks_exhausted = True
            trace["tasks_exhausted"] = {"since": self._tasks_dead_since,
                                        "round": turn.round_no}

    def _learn_imp_mine_ban(self, turn: Turn, trace: dict[str, Any]) -> None:
        """IKKDR0-Q4（用户裁决 2026-10-09：需要记忆）：敌 imp 破坏我方矿 → 该类矿禁采 10 回合。

        判定：上一回合存在、本回合消失的矿 + 上一回合**可见敌 imp 邻接**（破坏站桩期
        全图可见）+ 矿在我方对角线半区（平台不补刷规则按对角线半区生效）。
        → `imp_mine_ban[矿种] = 本回合 + 10`；工人选矿跳过该矿种至解禁
        （该半区该类矿 10 回合不会刷新，避免矿工在被清空的矿区空跑）。
        """
        if self.last_turn is None:
            return
        prev_mines = {p: k for p, k in self.last_turn.zones.items() if k in MINE_TYPES}
        foes = self.last_turn.enemy_imps()
        if not prev_mines or not foes:
            return
        for pos, kind in prev_mines.items():
            if turn.zones.get(pos) == kind:
                continue  # 仍在
            if not turn.own_half(pos):
                continue
            if not any(distance(foe.pos, pos) <= 1 for foe in foes):
                continue
            until = turn.round_no + 10
            if self.imp_mine_ban.get(kind, 0) < until:
                self.imp_mine_ban[kind] = until
                trace.setdefault("imp_mine_ban", []).append(
                    {"kind": kind, "pos": pos.dump(), "until": until}
                )

    def _learn(self, turn: Turn, trace: dict[str, Any]) -> None:
        relearn = False
        self._learn_tasks_exhausted(turn, trace)
        self._learn_imp_mine_ban(turn, trace)
        for role_id, ok in turn.last_action_results.items():
            cmd = self.last_commands.get(role_id)
            if not cmd:
                continue
            action = cmd.get("action")
            targets = parse_targets(cmd.get("targetPos"))
            if action == "build" and targets:
                self.buildable.record(targets[0], str(cmd.get("name") or ""), ok, turn.round_no)
                if not ok:
                    relearn = True
                    trace.setdefault("build_illegal", []).append(
                        {"pos": targets[0].dump(), "name": cmd.get("name")}
                    )
            elif action == "collect" and not ok and targets:
                # 采集失败（新闻封矿等）→ 拉黑 10 回合，再犯加重
                pos = targets[0]
                previous = self.mine_blacklist.get(pos, 0)
                penalty = 10 if previous <= turn.round_no else 40
                self.mine_blacklist[pos] = turn.round_no + penalty
                trace.setdefault("mine_blocked", []).append(pos.dump())
            elif action == "move" and not ok:
                # 移动失败（目标被占/争夺）→ 加速解卡看门狗，尽快放弃不可达目标
                fsm = self.worker_fsms.get(role_id)
                if fsm is not None:
                    fsm.note_move_failure()
        if relearn and self.layout is not None and turn.station() is not None:
            self.layout = compute_layout(turn, self.front, self.buildable)
            trace["layout_recomputed"] = True
        # 矿点消失则移出黑名单
        gone = [pos for pos in self.mine_blacklist if pos not in turn.mines()]
        for pos in gone:
            del self.mine_blacklist[pos]

    # ---- 白天 ----
    def _day(self, turn: Turn, commands: dict[int, dict[str, Any]], ctx: _Ctx) -> None:
        workers = turn.workers()
        layout = self.layout
        if layout is None:
            for worker in workers:
                cmd = self._worker_fsm(worker).decide(turn, worker, ctx)
                if cmd:
                    commands[worker.unit_id] = cmd
                ctx.reserve_from(cmd)
            return

        existing_weapons = {w.pos for w in turn.weapons()}
        existing_walls = {w.pos for w in turn.walls()}
        occupied = turn.occupied_cells()
        # 武器槽位上限（issue IKHYHT 死锁根因）：全局最多 3 座武器。
        # 若已达上限，布局里"没对齐"的炮位格**不能**再建（第4座被 LegalityGuard 拒），
        # 否则 brain 每回合派单→每回合被拒→修理工被永久占用、从不建墙。
        weapon_slots = max(0, WEAPON_LIMIT - len(existing_weapons))
        turrets_missing = [
            c for c in layout.turret_cells if c not in existing_weapons and c not in occupied
        ]
        # IKKIBC-Q4（实锤：敌召唤 BOSS 站上第 3 炮规划位 → 只建成 2 炮）：
        # 炮位被机器人占据 → 用"邻接 CP 的可建空格"替补，保证凑满 3 座。
        robot_cells = {r.pos for r in turn.hostile_robots}
        if robot_cells:
            # 武器建造区 = 距基地 1 格（ring1/蓝区，rules 硬校验）——替补格只能从这里找；
            # 可挖性由 _night_control_goal（邻接任意武器的安全格）兜底，不要求贴 CP。
            _st = turn.station()
            _foot = set(station_footprint(_st.pos)) if _st is not None else set()
            _ring1: set = set()
            for _fc in _foot:
                for _nb in _fc.neighbours():
                    if _nb not in _foot and 0 <= _nb.x < turn.width and 0 <= _nb.y < turn.height:
                        _ring1.add(_nb)
            fixed = []
            for c in turrets_missing:
                if c not in robot_cells:
                    fixed.append(c)
                    continue
                alt = next(
                    (p2 for p2 in sorted(_ring1, key=lambda q: (q.x, q.y))
                     if p2 != c and p2 not in existing_weapons and p2 not in existing_walls
                     and p2 not in occupied and p2 not in robot_cells
                     and p2 not in turrets_missing
                     and turn.land(p2)),
                    None,
                )
                if alt is not None:
                    ctx.trace.setdefault("turret_substitute", []).append(
                        {"from": c.dump(), "to": alt.dump()}
                    )
                    fixed.append(alt)
                # 无替补格 → 该炮位放弃（宁缺勿卡：派单到非法格会每回合被守卫拒绝）
            turrets_missing = fixed
        turrets_missing = turrets_missing[:weapon_slots]
        walls_missing = [
            c for c in layout.wall_cells if c not in existing_walls and c not in occupied
        ]
        phase = self.phases.phase(turn, not (turrets_missing or walls_missing))
        ctx.trace.update(
            phase=phase, turrets_missing=len(turrets_missing), walls_missing=len(walls_missing)
        )
        ctx.walls_missing = bool(walls_missing)
        ctx.need_gold = bool(turrets_missing) and turn.gold < WEAPON_BUILD_COST

        # 岗位：Day1——**1 号工人专职石料+建墙，2 号工人采矿+卖钱**（用户指定）。
        # 仅当"按进度一个工人建不完 14 墙"时，2 号才临时帮建（用户：可两个一起建）。
        walls_left = len(walls_missing)
        ctx.walls_left = walls_left
        stone_mines = turn.mines("stone")
        # 单工人建墙产能：每墙约 WALL_ROUNDS_PER 回合（采集+建造+挪位）；不共享矿 → 各采各的更快
        capacity = max(0.0, turn.rounds_until_night - BUILD_TRAVEL_BUFFER) / WALL_ROUNDS_PER
        stone_finishable = walls_left <= capacity
        day1_helper = (
            turn.day_index == 1
            and walls_missing
            and not stone_finishable
            and turn.round_in_day < DAY1_RUSH_DEADLINE
            and bool(stone_mines)
        )
        ctx.share_mines = False  # 不共享矿：双工人各选各的（共享=互相抢同一矿，更慢）
        # 角色固化：worker[0]=修理工，worker[1]=挖矿工（按 ID 升序）
        sorted_workers = sorted(workers, key=lambda w: w.unit_id)
        for index, worker in enumerate(sorted_workers):
            fsm = self._worker_fsm(worker)
            fsm.role = ROLE_REPAIRER if index == 0 else ROLE_MINER
        # 修理工触发（夜间/临近天黑归位）：D1-D2 不触发；D3+ 距天黑≤路径+4 触发；夜间有威胁触发
        ctx.repair_triggered = self._repair_triggered(turn, sorted_workers)
        # 需要凑武器升级费（挖矿工去卖钱的信号）
        ctx.need_weapon_gold = self._need_weapon_gold(turn)
        # 武器未到 L2 → 购买墙券/修复包时为其预留金币（"不能因升级围墙导致炮台不升级"）
        ctx.weapon_need_l2 = any(w.level < 2 for w in turn.weapons())

        # 建造分配：武器优先于墙；已被认领的格/工人不重复分配
        assigned = {
            fsm.build[0] for fsm in self.worker_fsms.values() if fsm.build is not None
        }
        # 在飞/已建的武器数（含已分配未完工）→ 剩余可建槽位
        in_flight_weapons = sum(
            1 for fsm in self.worker_fsms.values()
            if fsm.build is not None and fsm.build[1] in TOWER_TYPES
        )
        weapon_slots = max(0, WEAPON_LIMIT - len(existing_weapons) - in_flight_weapons)
        turrets_missing = turrets_missing[:weapon_slots]
        busy = set()
        gold_left = turn.gold
        for cell in turrets_missing:
            if gold_left < WEAPON_BUILD_COST:
                break
            if cell in assigned:
                gold_left -= WEAPON_BUILD_COST
                continue
            # 不得抢占"已有建造任务"的工人（否则会覆盖在途的建墙任务 → issue IKHYHT）
            free = [
                w for w in workers
                if w.unit_id not in busy and self._worker_fsm(w).build is None
            ]
            if not free:
                break
            # 炮塔建造**优先/仅派给修理工**（挖矿工专职采矿/卖钱，不抢建造；用户策略）；
            # 仅当修理工**阵亡**时才由挖矿工接手。
            repairers = [w for w in free if self._worker_fsm(w).role == ROLE_REPAIRER]
            repairer_alive = any(
                self._worker_fsm(w).role == ROLE_REPAIRER for w in workers
            )
            if repairers:
                pool = repairers
            elif repairer_alive:
                break            # 修理工活着但忙 → 挖矿工不抢建造
            else:
                pool = free       # 修理工阵亡 → 挖矿工接手
            worker = min(pool, key=lambda w: distance(w.pos, cell))
            # Q7 回退（IKKJ2x 实锤：电磁炮+挖矿工操控双败伤，且 day1 防线被推平）：
            # 恢复三门火箭 + pioneer 单操控。
            kind = ROCKET
            self._worker_fsm(worker).build = (cell, kind)
            busy.add(worker.unit_id)
            gold_left -= WEAPON_BUILD_COST
        walls_left = len(walls_missing)
        # 预留回合：入夜前剩余 ≤ 待建墙数 + 回程缓冲 → 必须立刻开建
        urgent = 0 < turn.rounds_until_night <= walls_left + BUILD_TRAVEL_BUFFER
        for worker in workers:
            if worker.unit_id in busy:
                continue
            fsm = self._worker_fsm(worker)
            if fsm.build is not None:
                continue
            stones = worker.backpack.count("stone")
            # 只有修理工负责建墙（若修理工阵亡，则由其余工人接手）；
            # 挖矿工仅在"第一天石头>20 且 墙<14"时紧急建墙
            repairer_alive = any(
                self._worker_fsm(w).role == ROLE_REPAIRER for w in workers
            )
            if fsm.role != ROLE_REPAIRER and repairer_alive:
                if not (turn.day_index == 1 and stones > 20 and walls_missing):
                    continue
            # 批量建造：采够一批进入 build_phase 后连续建完该批（不采一个建一个）。
            # Day1 首冲（issue#26）：目标一次采 12-14 块再连续建（减少往返）。
            # 但每座矿仅 10 块 → 采满一座(≥10)且**当前无更多石矿可采**时立即开建，
            # 避免"凑不满 14 就永远不开建"拖垮 Day1 墙环。
            if turn.day_index == 1:
                batch = max(1, min(walls_left, 14))
                if stones >= batch or (stones >= 10 and not stone_mines):
                    fsm.build_phase = True
            else:
                batch = min(STONE_BATCH, max(1, walls_left))
                if stones >= batch:
                    fsm.build_phase = True
            if stones == 0:
                fsm.build_phase = False
            # Day1 未达批量绝不开建（攒够一批再连续建）；入夜紧急兜底除外
            can_build = stones >= 1 and (fsm.build_phase or urgent or stones >= walls_left)
            if not walls_missing or not can_build:
                continue
            # 派单优先级（用户 2026-09-23 修订）：
            #   1) 曾被攻破的缺口最先补；
            #   2) **邻接已建墙最多**的格优先 → 保持已建墙**连续成环**（防"远处成环、近基地留缺口"被涌入）；
            #   3) 其余按布局顺序（正面迎敌侧优先）。
            breached_missing = {
                s.pos for s in self.wall_registry.missing() if s.breached_round > 0
            }
            existing_wall_pos = {w.pos for w in turn.walls()}

            def _adj_built(c) -> int:
                return sum(1 for nb in c.neighbours() if nb in existing_wall_pos)

            cand = [c for c in walls_missing if c not in assigned]
            cand.sort(key=lambda c: (
                0 if c in breached_missing else 1,
                -_adj_built(c),
                layout.wall_cells.index(c) if c in layout.wall_cells else 90 + c.x + c.y,
            ))
            cell = cand[0] if cand else None
            if cell is not None:
                fsm.build = (cell, WALL)
                assigned.add(cell)
                busy.add(worker.unit_id)

        # 升级任务分配（仅墙/备货 → 只派修理工；武器升级由炮手 pioneer 处理）
        # 白天只**采购**（allow_stock=True）；实际升级/修复留到夜间（用户：白天最大化采集）
        # 开拓者正在做任务/去任务点时，允许修理工代买武器券升级（用户 2026-09-23）
        pioneer_busy = self.pioneer_fsm.state in (
            STATE_TASK_ACCEPT, STATE_TASK_WAIT_ACCEPT,
            STATE_TASK_WORK, STATE_TASK_TRAVEL,
        )
        self._assign_repair_mission(
            turn, layout, ctx, workers, allow_stock=True, allow_weapon=pioneer_busy
        )
        # 炮手武器升级计划（由 fsm_pioneer 执行）
        ctx.gunner_upgrade = self._gunner_upgrade_plan(turn)
        # 归位锚点必须在工人决策前设置：修理工黄昏归位依赖 ctx.home_anchor
        # （此前在 pioneer 分支里才设置 → 工人阶段恒为 None → 修理工从不回防，实战 issue#25 卡墙外）
        ctx.home_anchor = layout.control_point
        ctx.turret_cells = tuple(layout.turret_cells)   # CP 不可达时退位用（IKI60Z）
        # 修理工夜间就位点 = 内圈邻墙格（issue#26：D4+ 夜到 repair_post 就位，非只回家）
        ctx.repair_anchor = layout.repair_post or layout.control_point

        # IKKIBC-Q6 BOSS 召唤令使用（用户裁决：有路线直捣敌基地，否则拆墙开路）：
        # 白天 use 登记召唤位（不得在任一基地建造区）→ 当夜首回合生成。
        holder = next(
            (u for u in turn.ours
             if u.kind == "worker" and "BossRobotSummonOrder" in u.backpack),
            None,
        )
        es = next((u for u in turn.enemy if u.kind == "station" and u.alive), None)
        if (
            holder is not None and es is not None and holder.unit_id not in commands
            and self._boss_used_day != turn.day_index
        ):
            pos = self._boss_summon_pos(turn, es)
            if pos is not None:
                commands[holder.unit_id] = use_command("BossRobotSummonOrder", pos)
                self._boss_used_day = turn.day_index
                ctx.trace["boss_summon_use"] = pos.dump()
                ctx.reserve_from(commands[holder.unit_id])

        for worker in workers:
            if worker.unit_id in commands:
                continue  # 晨拆门/召唤令等 brain 级指令优先，不被 FSM 覆盖
            cmd = self._safe_unit(self._worker_fsm(worker).decide, ctx.trace,
                                  "worker%d" % worker.unit_id, turn, worker, ctx)
            if cmd is None:
                cmd = self._vacate_layout_cell(turn, worker, ctx)
            if cmd:
                commands[worker.unit_id] = cmd
            ctx.reserve_from(cmd)

        pioneer = turn.pioneer()
        if pioneer is not None:
            ctx.home_anchor = layout.control_point
            prev_state = self.pioneer_fsm.state
            # 任务求解优先（IKHYU3 根因）：驻留任务点且任务进行中时先跑求解——
            # submit 占本回合角色动作；这样"入夜前归位"不会在答案就绪时抢走动作、导致任务被终止。
            if self.pioneer_fsm.state == STATE_TASK_WORK and turn.phase_task:
                # P0-3 保险②：上回合 llmResp 若被 news/treasure 占用，任务不得消费
                self.task_session.llm_resp_ok = self.llm_owner in ("", "task")
                out = self.task_planner.work(turn, self.task_session)
                if out.prompt:
                    ctx.prompt = out.prompt
                    if self._llm_waiting:
                        # P0-3 保险①：任务 prompt 抢占通道 → 撤销 news/treasure 孤儿提问
                        ctx.trace["llm_preempt"] = self._llm_waiting
                        self._llm_waiting = ""
                    self.llm_owner = "task"
                    ctx.trace["llm_task"] = True
                ctx.execute_cmd = out.execute_cmd
                if out.submit is not None:
                    commands[pioneer.unit_id] = out.submit
                    self._task_work_since = turn.round_no  # P1-A：提交=推进 → 重置卡死计时
                    ctx.trace.setdefault("task", {})["submit"] = True
                # P1-A（IKKJ2K 实锤）：TASK_WORK 连续 12+ 轮无 submit（LLM 响应
                # 丢失/求解器卡死）→ 放弃任务拉黑该任务点，回 GUARD 重选，否则
                # pioneer 站到被平台超时终止，20 轮全废。prompt 每轮重发不算推进。
                if (
                    commands.get(pioneer.unit_id) is None
                    and self._task_work_since is not None
                    and turn.round_no - self._task_work_since > TASK_STALL_LIMIT
                ):
                    ctx.trace["task_stall_abort"] = turn.round_no - self._task_work_since
                    if self.pioneer_fsm.task_point is not None:
                        self.pioneer_fsm.failed_task_points.add(
                            self.pioneer_fsm.task_point
                        )
                    self.task_session.reset()
                    self.pioneer_fsm.state = STATE_GUARD
                    self.pioneer_fsm.task_point = None
                    self._task_work_since = None
            elif self.task_session.stage == ST_CONFIRM:
                # P1-8：提交后任务被平台撤下/FSM 已退出任务态 → 求解器门控不再命中，
                # 但确认收尾（completed/SOP）必须补跑，否则成功提交被静默丢弃。
                # out 不再产生 prompt/cmd/submit，仅完成 _confirm_done 并重置会话。
                self.task_planner.work(turn, self.task_session)
                ctx.trace["task_confirm"] = True
            # 本回合未提交，再让 FSM 决定走位/接任务/归位
            if pioneer.unit_id not in commands:
                cmd = self.pioneer_fsm.day_cmd(turn, pioneer, layout.control_point, ctx)
                if cmd:
                    commands[pioneer.unit_id] = cmd
                    ctx.reserve_from(cmd)
            # 新任务确认 → 重置求解会话（同文本任务重复接取也必须全新开始）
            if self.pioneer_fsm.state == STATE_TASK_WORK and prev_state != STATE_TASK_WORK:
                self.task_session.reset()
                self._task_work_since = turn.round_no
            elif self.pioneer_fsm.state != STATE_TASK_WORK:
                self._task_work_since = None
        self._maybe_medicine(turn, commands)

    # ---- 黑夜 ----
    def _night(self, turn: Turn, commands: dict[int, dict[str, Any]], ctx: _Ctx) -> None:
        ctx.trace["phase"] = "NIGHT_DEFENSE"
        self._observe_spawns(turn, ctx)
        report = self.threat.evaluate(turn)
        ctx.threat_level = report.level
        ctx.trace["threat"] = report.dump()
        if self.layout is not None:
            ctx.home_anchor = self.layout.control_point
            ctx.repair_anchor = self.layout.repair_post or self.layout.control_point
        # 机器人危险圈 + 内圈安全锚点（实战教训：夜采/夜卖被兵潮打死）
        ctx.robot_cells = tuple(r.pos for r in turn.hostile_robots)  # IKKIBC-Q6：排除自家召唤
        interior = self._interior_cells(turn)
        ctx.safe_anchor = interior[0] if interior else ctx.home_anchor
        ctx.danger_workers = {
            w.unit_id for w in turn.workers()
            if any(distance(w.pos, rc) <= WORKER_DANGER_DIST for rc in ctx.robot_cells)
        }
        # 基地是否有危险（机器人逼近基地）→ 决定工人是"撤内圈"还是"直接避让"
        station = turn.station()
        ctx.base_in_danger = bool(
            station is not None and any(
                distance(r.pos, cell) <= BASE_DANGER_DIST
                for r in turn.hostile_robots
                for cell in station_footprint(station.pos)
            )
        )
        # 城墙危险阈值（问题4）：预计本夜机器人总伤害 > 城墙总HP×阈值 → 危险
        ctx.wall_danger = self._wall_danger(turn)
        # 修理工触发（问题2 修复：夜间也要计算，此前只在 _day 算 → 夜里恒为 False）
        ctx.repair_triggered = self._repair_triggered(
            turn, sorted(turn.workers(), key=lambda w: w.unit_id)
        )
        ctx.trace["wall_danger"] = ctx.wall_danger
        # 修墙岗仅限：Day4+（BOSS 夜）或 墙严重受损（≥3 面掉血 或 有墙<50%）。
        # Night1-3 相对轻松（事实：机器人主攻基地、顺路才杀工人）→ 不设岗，双工人全力采矿。
        hurt_walls = [
            w for w in turn.walls()
            if w.health < WALL_MAX_HP[min(max(w.level, 1), 3) - 1]
        ]
        severe = len(hurt_walls) >= 3 or any(
            w.health < 0.5 * WALL_MAX_HP[min(max(w.level, 1), 3) - 1] for w in hurt_walls
        )
        if turn.day_index >= 4 or severe:
            workers_sorted = sorted(turn.workers(), key=lambda w: w.unit_id)
            if workers_sorted:
                ctx.repair_worker = workers_sorted[0].unit_id
        # 仅对处于危险圈的工人分配召回格（不再群体召回）
        if ctx.danger_workers:
            danger_list = [w for w in turn.workers() if w.unit_id in ctx.danger_workers]
            ctx._recall_cells = {
                w.unit_id: cell for w, cell in zip(danger_list, interior)
            }
        if self.layout is not None:
            existing_walls = {w.pos for w in turn.walls()}
            existing_weapons = {w.pos for w in turn.weapons()}
            ctx.walls_missing = any(
                c not in existing_walls for c in self.layout.wall_cells
            )
            ctx.need_gold = (
                any(c not in existing_weapons for c in self.layout.turret_cells)
                and turn.gold < WEAPON_BUILD_COST
            )
        else:
            ctx.walls_missing = False
            ctx.need_gold = False
        # 夜间升级任务分配：修理工用白天采购的券升级/修复墙（升级=回血，省修复包）。
        # **夜间不备货**（用户 2026-09-23：夜里买来不及，修复包必须白天提前备足）。
        self._assign_repair_mission(
            turn, self.layout, ctx, sorted(turn.workers(), key=lambda w: w.unit_id),
            allow_stock=False,
        )
        # IKKIBC-Q5：建造仅白天合法（§4.5.1）——夜间清掉在途建造任务，
        # 防止修理工为"未建成的背墙"整夜站桩墙外（次日清晨 _day 会重新派单）。
        for _w in turn.workers():
            _fsm = self._worker_fsm(_w)
            if _fsm.build is not None:
                _fsm.build = None
        pioneer = turn.pioneer()
        if pioneer is not None and self.layout is not None:
            cp = self.layout.control_point
            robots_alive = list(turn.hostile_robots)
            # 兵潮已清 + 天亮前有余量 → 开拓者出行动（任务/买券），不再蹲守
            if not robots_alive and turn.rounds_until_dawn > 30:
                prev = self.pioneer_fsm.state
                # 任务求解优先：答案就绪先提交（同 _day，防走位抢动作）
                if self.pioneer_fsm.state == STATE_TASK_WORK and turn.phase_task:
                    # P0-3 保险②：同 _day——通道归属守卫
                    self.task_session.llm_resp_ok = self.llm_owner in ("", "task")
                    out = self.task_planner.work(turn, self.task_session)
                    if out.prompt:
                        self._task_work_since = turn.round_no  # P1-A：推进即重置
                        ctx.prompt = out.prompt
                        if self._llm_waiting:
                            ctx.trace["llm_preempt"] = self._llm_waiting
                            self._llm_waiting = ""
                        self.llm_owner = "task"
                        ctx.trace["llm_task"] = True
                    ctx.execute_cmd = out.execute_cmd
                    if out.submit is not None:
                        commands[pioneer.unit_id] = out.submit
                        self._task_work_since = turn.round_no  # P1-A：提交=推进
                    # P1-A：同 _day——夜间任务卡死同样放弃（回 CP 守炮更值）
                    if (
                        commands.get(pioneer.unit_id) is None
                        and self._task_work_since is not None
                        and turn.round_no - self._task_work_since > TASK_STALL_LIMIT
                    ):
                        ctx.trace["task_stall_abort_night"] = (
                            turn.round_no - self._task_work_since
                        )
                        if self.pioneer_fsm.task_point is not None:
                            self.pioneer_fsm.failed_task_points.add(
                                self.pioneer_fsm.task_point
                            )
                        self.task_session.reset()
                        self.pioneer_fsm.state = STATE_GUARD
                        self.pioneer_fsm.task_point = None
                        self._task_work_since = None
                elif self.task_session.stage == ST_CONFIRM:
                    # P1-8：同 _day——提交后任务撤下也要补跑确认收尾
                    self.task_planner.work(turn, self.task_session)
                    ctx.trace["task_confirm"] = True
                if pioneer.unit_id not in commands:
                    cmd = self.pioneer_fsm.day_cmd(turn, pioneer, cp, ctx)
                    if cmd:
                        commands[pioneer.unit_id] = cmd
                        ctx.reserve_from(cmd)
                if self.pioneer_fsm.state == STATE_TASK_WORK and prev != STATE_TASK_WORK:
                    self.task_session.reset()
                    self._task_work_since = turn.round_no
                elif self.pioneer_fsm.state != STATE_TASK_WORK:
                    self._task_work_since = None
                if pioneer.unit_id in commands:
                    ctx.reserve_from(commands[pioneer.unit_id])
            else:
                # IKKIBC-Q4（实锤：敌 BOSS 站炮位旁 → CP 危险 → 躲内圈 → 全夜零开火）：
                # 改为选"邻接最多武器"的**安全**控制格——保持控炮能力优先于绝对安全。
                goal = self._night_control_goal(
                    turn, ctx, pioneer, avoid=ctx.repair_anchor
                )
                cmd = self.pioneer_fsm.move_to_guard(turn, pioneer, goal, ctx)
                if cmd:
                    commands[pioneer.unit_id] = cmd
                    ctx.reserve_from(cmd)
        # 应急道具（Day6+，用户）：城墙危险时用炸弹/眩晕清群（占用开拓者动作，优先于开火）
        if (
            pioneer is not None and pioneer.unit_id not in commands
            and turn.day_index >= 6 and ctx.wall_danger
        ):
            item_cmd = self._emergency_item(turn, pioneer)
            if item_cmd is not None:
                commands[pioneer.unit_id] = item_cmd
        # 操控占用动作（已确认）：移动中不能控炮 → 仅当开拓者无指令时才开火
        if pioneer is not None and pioneer.unit_id not in commands:
            self.fire.plan(turn, pioneer, commands, ctx.trace)
        # Q7 回退（IKKJ2x）：挖矿工夜控第二座武器整段撤销——errorCode=4 实锤
        # （fire.plan 只占武器指令，worker 循环照常给挖矿工下发 move → 同轮
        # "操控+行动"被平台拒绝，电磁炮开火与挖矿工移动双双作废）。
        # IKKIBC-Q6：夜间驱动我方召唤机器人（有路线直捣敌基地，否则拆墙开路）
        self._drive_summon_robots(turn, commands, ctx)
        for worker in turn.workers():
            if worker.unit_id in commands:
                continue  # 夜控/召回等 brain 级指令优先，不被 FSM 覆盖
            cmd = self._safe_unit(self._worker_fsm(worker).decide, ctx.trace,
                                  "worker%d" % worker.unit_id, turn, worker, ctx)
            if cmd:
                commands[worker.unit_id] = cmd
            ctx.reserve_from(cmd)
        self._maybe_medicine(turn, commands)

    # ---- IKKIBC-Q4：夜间控制格选择 ----
    def _night_control_goal(
        self, turn: Turn, ctx: "_Ctx", controller, avoid=None
    ) -> Pos | None:
        """选"邻接最多武器"的安全可达格作为夜控就位目标。

        CP 有机器人贴脸（如敌方召唤 BOSS 占位）时不再二选一躲安全角——
        在 CP/炮位邻域找无机器人贴脸、邻接武器最多的格；全部不安全才退安全锚点。"""
        if self.layout is None:
            return ctx.safe_anchor or ctx.home_anchor
        cp = self.layout.control_point
        robots = list(turn.hostile_robots)
        occupied = turn.occupied_cells()
        weapons = turn.weapons()
        cands = {cp}
        for w in weapons:
            cands.update(w.pos.neighbours())
        best, best_key = None, None
        for c in cands:
            if not (0 <= c.x < turn.width and 0 <= c.y < turn.height):
                continue
            if not turn.land(c):
                continue
            if c != controller.pos and c in occupied:
                continue
            if avoid is not None and c == avoid:
                continue  # Q5：repair_post 是修理工的岗，操控者不得占位
            adj = sum(1 for w in weapons if distance(c, w.pos) <= 1)
            rmin = min((distance(c, r.pos) for r in robots), default=99)
            unsafe = 1 if rmin <= PIONEER_FLEE_DIST else 0
            key = (unsafe, -adj, -rmin, distance(c, cp), c.x, c.y)
            if best_key is None or key < best_key:
                best, best_key = c, key
        if best is None:
            return ctx.safe_anchor or cp
        if best_key[0] == 1 and ctx.safe_anchor is not None:
            return ctx.safe_anchor   # 全部控制格都贴脸 → 保命优先
        return best

    # ---- IKKIBC-Q6：BOSS 召唤位 / 夜间驱动 ----
    def _boss_summon_pos(self, turn: Turn, es) -> Pos | None:
        """召唤位：敌基地外围（距敌基地 6-9 格、避开建造区/占用/中立元素），
        朝地图中心方向（夜间我方机器人来向的反向，生存窗口更大）。"""
        cx, cy = (turn.width - 1) / 2.0, (turn.height - 1) / 2.0
        dx, dy = cx - es.pos.x, cy - es.pos.y
        norm = max(abs(dx), abs(dy)) or 1.0
        ux, uy = dx / norm, dy / norm
        occupied = turn.occupied_cells()
        for dist in (8, 7, 9, 6):
            for j in (0, 1, -1, 2, -2):
                x = int(round(es.pos.x + ux * dist + uy * j))
                y = int(round(es.pos.y + uy * dist - ux * j))
                pos = Pos(x, y)
                if not (0 <= x < turn.width and 0 <= y < turn.height):
                    continue
                if not turn.land(pos) or pos in occupied:
                    continue
                if distance(pos, es.pos) < 6:   # 避开建造区（平台规则）
                    continue
                return pos
        return None

    def _drive_summon_robots(self, turn: Turn, commands: dict, ctx: "_Ctx") -> None:
        """夜间驱动我方召唤机器人（接口 §2.2/§4.5.4：可控机器人以机器人 ID 为 key
        下发 move/attack；attack 可打对方英雄/基地/建筑）。
        用户裁决 IKKIBC-Q6：**有路线直捣敌基地**；无路线 → 拆墙开路。"""
        es = next((u for u in turn.enemy if u.kind == "station" and u.alive), None)
        if es is None:
            return
        base_cells = station_footprint(es.pos)
        for robot in turn.summon_robots:
            if not robot.alive or robot.robot_id in commands:
                continue
            adj_base = next(
                (c for c in base_cells if distance(robot.pos, c) <= 1), None
            )
            if adj_base is not None:
                commands[robot.robot_id] = {
                    "action": "attack", "targetPos": [adj_base.dump()],
                }
                ctx.trace.setdefault("boss_cmd", []).append(
                    {"robot": robot.robot_id, "cmd": "attack_base"}
                )
                continue
            step = self._robot_step_to(turn, robot.pos, base_cells)
            if step is not None:
                commands[robot.robot_id] = {
                    "action": "move", "targetPos": [step.dump()],
                }
                continue
            # 无路线 → 拆墙开路：邻接敌墙攻击之，否则走向最近敌墙
            adj_wall = next(
                (u.pos for u in turn.enemy
                 if u.kind == "wall" and u.alive and distance(robot.pos, u.pos) <= 1),
                None,
            )
            if adj_wall is not None:
                commands[robot.robot_id] = {
                    "action": "attack", "targetPos": [adj_wall.dump()],
                }
                ctx.trace.setdefault("boss_cmd", []).append(
                    {"robot": robot.robot_id, "cmd": "attack_wall"}
                )
                continue
            walls = [u for u in turn.enemy if u.kind == "wall" and u.alive]
            if walls:
                near = min(walls, key=lambda w: distance(robot.pos, w.pos))
                step = self._robot_step_to(turn, robot.pos, [near.pos])
                if step is not None:
                    commands[robot.robot_id] = {
                        "action": "move", "targetPos": [step.dump()],
                    }

    def _robot_step_to(self, turn: Turn, start: Pos, target_cells) -> Pos | None:
        """机器人 BFS 寻路（8 向）：目标 = 邻接目标格的空格；阻挡 = 建筑/角色/
        机器人/中立元素。返回应走的第一步；已邻接目标或不可达 → None。"""
        from collections import deque

        goals = set()
        for c in target_cells:
            for nb in c.neighbours():
                if 0 <= nb.x < turn.width and 0 <= nb.y < turn.height:
                    goals.add(nb)
        if start in goals:
            return None
        blocked: set[Pos] = set()
        for u in (*turn.ours, *turn.enemy):
            if u.kind in ("wall", "station"):
                blocked.update(turn.footprint(u))
            else:
                blocked.add(u.pos)
        for r in turn.robots:
            if r.alive:
                blocked.add(r.pos)
        blocked.update(turn.zones.keys())
        blocked.discard(start)
        prev: dict[Pos, Pos | None] = {start: None}
        queue: deque[Pos] = deque([start])
        while queue:
            cur = queue.popleft()
            if cur in goals:
                node = cur
                while prev[node] is not None and prev[node] != start:
                    node = prev[node]
                if prev[node] == start:
                    return node
                return None
            for nb in cur.neighbours():
                if nb in prev:
                    continue
                if not (0 <= nb.x < turn.width and 0 <= nb.y < turn.height):
                    continue
                if nb in blocked and nb not in goals:
                    continue
                prev[nb] = cur
                queue.append(nb)
        return None

    # ---- 32进16：捣乱鬼 + 反抓防御 ----
    # 追击派单参数（用户 2026-10-09 裁决，只采纳三点：邻接即抓 / 站桩中 2-4 步派单 / 不派开拓者）
    HUNT_MIN_DIST = 2     # 站桩敌 imp 距我方工人 ≥2（=1 走上方邻接抓逻辑）
    HUNT_MAX_DIST = 4     # ≤4 步：敌 imp 站桩 4 回合窗口内必能就位（>4 到达前它已打完）
    HUNT_ROBOT_GUARD = 3  # 工人身边 ≤3 格有机器人 → 不派（夜间安全优先，追击不冒机器人风险）

    def _imp_and_catch_defense(self, turn: Turn, commands: dict[int, dict[str, Any]], ctx) -> None:
        """捣乱鬼决策 + 全队抓捕防御（用户 2026-10-09 裁决版）。

        防御三点：
        1. **邻接即抓**：可见敌方 imp 与我方任一角色距离 1 → 立即 catch
           （可覆盖工人/imp 指令；任务关键动作 submitAnswer/acceptTask/summonTreasure 永不覆盖）。
        2. **站桩追击**：敌 imp 在我方半区、**贴着我方矿**（站桩破坏强信号）、
           最近工人在 2~4 步内 → 派其前往抓捕（走到即触发邻接抓）。
           即使敌 imp 弃桩逃跑，进度清零 + 威慑成立（见桩必反应 → 它只能挑远矿打）。
        3. **永不派开拓者追击**（任务 80 分 > 抓捕 20 金+保矿；任务 deadline 仅 15 回合）。
           开拓者仅保留第 1 条邻接即抓（顺路白捡）。

        不追的情况（未采纳，即为不做）：>4 步不派、非矿旁不追、敌方半区不远征。
        """
        critical = {"submitAnswer", "acceptTask", "summonTreasure"}
        for foe in turn.enemy_imps():
            for role in (*turn.workers(), turn.pioneer(), turn.imp()):
                if role is None:
                    continue
                if distance(role.pos, foe.pos) != 1:
                    continue
                if not turn.own_half(foe.pos) and role.kind != IMP:
                    continue
                existing = commands.get(role.unit_id)
                if existing is not None and existing.get("action") in critical:
                    continue
                commands[role.unit_id] = catch_command(foe.pos)
                ctx.trace.setdefault("catch_defense", []).append(
                    {"role": role.unit_id, "foe": foe.pos.dump()}
                )
                break  # 一个敌人一个抓捕者
        # ---- 2. 站桩追击派单（仅工人；每回合重判，敌 imp 弃桩即自动停派） ----
        hunted: set[int] = set()  # 本回合已派出的工人（一人只追一个目标）
        for foe in turn.enemy_imps():
            if not turn.own_half(foe.pos):
                continue
            # 站桩强信号：贴着我方半区仍有余量的矿
            if not any(
                turn.zones.get(nb) in MINE_TYPES and turn.mine_remain.get(nb, 0) > 0
                for nb in foe.pos.neighbours()
            ):
                continue
            hunter = None
            for w in sorted(
                (w for w in turn.workers() if w.alive and w.unit_id not in hunted),
                key=lambda w: (distance(w.pos, foe.pos), w.unit_id),
            ):
                d = distance(w.pos, foe.pos)
                if not (self.HUNT_MIN_DIST <= d <= self.HUNT_MAX_DIST):
                    continue
                existing = commands.get(w.unit_id)
                if existing is not None and existing.get("action") in critical:
                    continue
                # 机器人贴身 → 不派（工人安全 > 追击）
                if any(
                    distance(w.pos, rc) <= self.HUNT_ROBOT_GUARD
                    for rc in ctx.robot_cells
                ):
                    continue
                hunter = w
                break
            if hunter is None:
                continue
            step = step_toward(turn, hunter, foe.pos, ctx.reserved)
            if step is None:
                continue
            commands[hunter.unit_id] = move_command(step)
            hunted.add(hunter.unit_id)
            ctx.trace.setdefault("catch_hunt", []).append(
                {"role": hunter.unit_id, "foe": foe.pos.dump()}
            )
        imp = turn.imp()
        if imp is None or imp.unit_id in commands:
            return
        cmd = self._safe_unit(self.imp_fsm.decide, ctx.trace, "imp", turn, imp, ctx)
        if cmd is not None:
            commands[imp.unit_id] = cmd
            ctx.reserve_from(cmd)

    def _corridor_cells(self, turn: Turn) -> tuple:
        """出生点质心 → 我方基地 的行军走廊采样格（B 方案安全矿定义）。

        只取**远离我方基地**的部分（距基地 > CORRIDOR_BASE_MARGIN）——近基地处有墙/炮塔保护，
        否则基地附近的矿会被误判为"走廊内"而无矿可采。
        """
        if not self.robot_spawn_log or turn.station() is None:
            return ()
        spawns = [Pos(x, y) for entry in self.robot_spawn_log for (x, y) in entry["spawns"]]
        if not spawns:
            return ()
        sx = round(sum(p.x for p in spawns) / len(spawns))
        sy = round(sum(p.y for p in spawns) / len(spawns))
        base = turn.station().pos
        bx, by = base.x, base.y
        steps = max(abs(bx - sx), abs(by - sy))
        cells = []
        for i in range(steps + 1):
            px = round(sx + (bx - sx) * i / max(1, steps))
            py = round(sy + (by - sy) * i / max(1, steps))
            if distance(Pos(px, py), base) > CORRIDOR_BASE_MARGIN:
                cells.append(Pos(px, py))
        return tuple(cells)

    def _wall_danger(self, turn: Turn) -> bool:
        """城墙危险阈值（问题4）：预计本夜机器人总伤害 > 城墙总HP×WALL_DANGER_RATIO → 危险。
        预计伤害 = 机器人总攻击力 × 清场回合数（清场回合 = 机器人总HP / 我方DPS，封顶 60）。"""
        robots = list(turn.hostile_robots)
        if not robots:
            return False
        from .threat import ROBOT_ATK
        total_atk = sum(ROBOT_ATK.get(r.kind, 5) for r in robots)
        total_hp = sum(r.health for r in robots)
        dps = sum(20 * max(1, w.level) for w in turn.weapons()) / 3.0
        rounds = min(total_hp / dps, 60.0) if dps > 0 else 60.0
        damage = total_atk * rounds
        wall_hp = sum(w.health for w in turn.walls())
        return damage > wall_hp * WALL_DANGER_RATIO

    def _repair_triggered(self, turn: Turn, workers) -> bool:
        """修理工触发：D1-D2 不触发；D3+ 距天黑≤路径+4 触发；夜间有威胁/城墙危险触发。"""
        if turn.day_index <= 2:
            return False
        if turn.is_night:
            station = turn.station()
            near = bool(
                station is not None and any(
                    distance(r.pos, cell) <= 6
                    for r in turn.hostile_robots
                    for cell in station_footprint(station.pos)
                )
            )
            hurt = any(
                w.health < WALL_MAX_HP[min(max(w.level, 1), 3) - 1] for w in turn.walls()
            )
            return near or hurt or self._wall_danger(turn)
        repairer = next(
            (w for w in workers if self._worker_fsm(w).role == ROLE_REPAIRER), None
        )
        home = self.layout.control_point if self.layout else None
        if repairer is None or home is None:
            return False
        return 0 < turn.rounds_until_night <= distance(repairer.pos, home) + REPAIR_MARGIN

    def _assign_repair_mission(
        self, turn: Turn, layout, ctx, workers, *, allow_stock: bool, allow_weapon: bool = False
    ) -> None:
        """把 1 个墙升级/备货（或武器升级）任务派给修理工（每回合最多 1 个）。

        - allow_stock=True（白天）：可派 WallFixer 备货任务（白天采购）。
        - allow_stock=False（夜间）：只派墙升级任务（夜间执行，升级=回血）。
        - allow_weapon=True（用户 2026-09-23）：开拓者**正在做任务/去任务点**时，
          让修理工也买武器券升级炮台（提升任务效率）。
        """
        repair_worker = next(
            (w for w in workers if self._worker_fsm(w).role == ROLE_REPAIRER), None
        )
        if repair_worker is None or layout is None:
            return
        # 缺口优先（用户 2026-09-23）：白天有"**被攻破**的墙缺口"时，清掉升级/备货任务、不派新任务，
        # 让修理工专心采石补缺口（否则夜间派下的升级任务会占用白天，中间墙整天没人补，如 IKHZOS）。
        # 注意：仅针对"曾存在→被打掉"的缺口；Day1 尚未建完的初始缺口不阻塞升级。
        breached_gap = any(
            (not s.exists) and s.breached_round > 0
            for s in self.wall_registry.walls.values()
        )
        if turn.is_day and breached_gap:
            self._worker_fsm(repair_worker).upgrade = None
            return
        rfsm = self._worker_fsm(repair_worker)
        plan = list(self.upgrades.plan(
            turn, cp=layout.control_point, registry=self.wall_registry, front=self.front
        ))
        # **备货(stock)可抢占墙升级(wall)**（用户 2026-09-23）：修复包是夜间防御前提，
        # 不能被上一回合领的"墙升级券任务"一直挡住（IKI7VH：D3 的 WallFixer 被 D2 的旧任务饿死）。
        top_stock = next((m for m in plan if m.kind == "stock"), None)
        if (
            rfsm.upgrade is not None
            and rfsm.build is None
            and top_stock is not None
            and rfsm.upgrade[1] == "wall"
        ):
            rfsm.upgrade = None   # 允许备货抢占
        if rfsm.upgrade is not None or rfsm.build is not None:
            return
        taken_targets = {
            fsm.upgrade[0] for fsm in self.worker_fsms.values()
            if fsm.upgrade and hasattr(fsm.upgrade[0], "dump")
        }
        # 开拓者做任务时（allow_weapon）：维修工**优先补位升级武器**（用户 2026-09-23：
        # "开拓者在做任务，维修工应该去补位购买武器升级券升级武器，不能只靠开拓者"）
        if allow_weapon:
            # 顺序：**备货(stock, 如 WallFixer) 仍最前** → 武器券 → 其余（用户 2026-09-23：
            # "每次到商店应全局审视还需要买什么"，不能把修复包挤到后面、来回走还买不成）
            plan = (
                [m for m in plan if m.kind == "stock"]
                + [m for m in plan if m.kind == "weapon"]
                + [m for m in plan if m.kind not in ("stock", "weapon")]
            )
        for mission in plan:
            if mission.kind not in ("wall", "stock"):
                if not (allow_weapon and mission.kind == "weapon"):
                    continue  # 武器/基地升级默认不派给工人（开拓者做任务时例外）
            if mission.kind == "stock" and not allow_stock:
                continue  # 夜间不采购
            if mission.target is not None and mission.target in taken_targets:
                continue
            if mission.kind == "stock":
                rfsm.upgrade = (mission.voucher, "stock", mission.qty)
            else:
                rfsm.upgrade = (mission.target, mission.kind)
                taken_targets.add(mission.target)
            ctx.trace.setdefault("upgrade_assigned", []).append(
                {"worker": repair_worker.unit_id, "kind": mission.kind,
                 "target": mission.target.dump() if mission.target is not None else None,
                 "voucher": mission.voucher}
            )
            break  # 每回合最多 1 个

    def _llm_budget_ok(self, turn: Turn) -> bool:
        """每日 LLM 上限 3 次（跨天重置）；errorCode=5 → 当日封禁。

        注意：**仅用于非任务期 LLM**（如宝藏推断）。自进化任务执行期间 LLM 不限次且
        不占额度（接口文档 errorCode=5），任务求解不调用本函数。
        errorCode=5 = 平台告知 LLM 额度超限（ban 状态由 _decide_core 设置并记 trace）
        → 当日本模块不再发任何非任务 prompt，防止连续超限持续计数/堆异常。
        """
        if turn.day_index != self.llm_day:
            self.llm_day = turn.day_index
            self.llm_calls_today = 0
        if self.llm_ban_day == turn.day_index:
            return False  # 当日已因超限被封
        return self.llm_calls_today < LLM_DAILY_LIMIT

    def _emergency_item(self, turn: Turn, pioneer) -> dict[str, Any] | None:
        """应急道具（Day6+）：找机器人最密的格（3×3 内最多，且靠基地），用炸弹/眩晕。"""
        item = next((i for i in pioneer.backpack if i in ("Bomb", "DizzyWeapon")), None)
        if item is None:
            return None
        station = turn.station()
        robots = list(turn.hostile_robots)
        if station is None or len(robots) < 3:
            return None
        best, best_n = None, 0
        for r in robots:
            n = sum(1 for o in robots if distance(r.pos, o.pos) <= 1)
            if n > best_n or (
                n == best_n and best is not None
                and distance(r.pos, station.pos) < distance(best, station.pos)
            ):
                best, best_n = r.pos, n
        if best is None or best_n < 3:
            return None
        return use_command(item, best)

    def _need_weapon_gold(self, turn: Turn) -> bool:
        """有武器未升满且金币不足 → 挖矿工去卖钱凑升级费（用户 2026-09-23：D4 前 3 门 L3）。"""
        weapons = turn.weapons()
        if not weapons:
            return False
        if any(w.level < 2 for w in weapons):
            return turn.gold < WEAPON_L1_COST + RESERVE_GOLD
        if any(w.level < 3 for w in weapons):
            return turn.gold < WEAPON_L2_COST + RESERVE_GOLD
        return False

    def _gunner_upgrade_plan(self, turn: Turn):
        """炮手的武器升级计划 → (目标Pos, "weapon") 或 None。优先 L1→L2，再 L2→L3。"""
        weapons = sorted(turn.weapons(), key=lambda w: (w.level, w.unit_id))
        for w in weapons:
            if w.level == 1:
                return (w.pos, "weapon")
        for w in weapons:
            if w.level == 2:
                return (w.pos, "weapon")
        return None

    def _record_news(self, turn: Turn, ctx) -> None:
        """每回合存档 worldNews（官方消息+民间传闻），并喂给新闻经济/宝藏模块。"""
        trace = ctx.trace
        official = (turn.official_news or "").strip()
        folk = (turn.folk_legends or "").strip()
        in_task = bool(turn.phase_task)
        # P0-3（F8 真因）：原判据 `pioneer_fsm.state == STATE_TASK_WORK` 在任务执行
        # 沙盒命令的间隙会被误判为空闲 → 宝藏/新闻 prompt 混进任务会话。
        # turn.phase_task 才是任务会话活跃的可靠信号。
        if official:
            self.news_economy.update(official, turn.day_index)
            # 记录新闻解析结果（预测窗口/LLM 兜底），便于后续定位与调试
            if self.news_economy.last_pred:
                trace["news_pred"] = self.news_economy.last_pred
            elif self.news_economy.predictions:
                trace["news_pred"] = {k: dict(v) for k, v in self.news_economy.predictions.items()}
            # 确定性解析失败 → 少量每日 LLM 兜底（非任务期，不占任务额度）
            if (
                self.news_economy.last_new
                and not self.news_economy.last_parsed
                and not in_task
            ):
                if self._ask_llm(turn, ctx, "news", NewsEconomy.prompt(official)):
                    trace["news_llm"] = True
        if folk:
            if self.treasure.observe(folk, turn.day_index):
                trace["treasure_clue"] = len(self.treasure.legends)
        # 线索足够且尚未召唤 → LLM 推断宝藏（地点/祭品/时间）。
        # IKKDR0-Q5（F18 根因 2）：旧逻辑包在 `if folk:` 里——ts=2/3 重推把
        # _last_infer_len 清零后，当天无新传闻就永不重推（宝藏死案）。
        # 移出：每回合检查 needs_inference（召唤失败重置计数 → 主动重推，不等新传闻）。
        if self.treasure.needs_inference() and not in_task:
            _tp = self.treasure.prompt(
                turn.width, turn.height, turn.day_index,
                zones=zones_text(turn),
                offerings=offerings_from_shop(turn.shop_prices),
            )
            if self._ask_llm(turn, ctx, "treasure", _tp):
                trace["treasure_llm"] = True
                trace["treasure_llm_prompt"] = _tp[:600]
                self.treasure.mark_inferred()   # 记下已就本批线索问过
        if not official and not folk:
            return
        entry = {"round": turn.round_no, "day": turn.day_index,
                 "official": official, "folk": folk}
        # 去重：与上一条完全相同则跳过
        if self.news_log and self.news_log[-1]["official"] == official and self.news_log[-1]["folk"] == folk:
            return
        self.news_log.append(entry)
        trace["news"] = {"official": official[:80], "folk": folk[:80]}

    def _ask_llm(self, turn: Turn, ctx, kind: str, prompt: str) -> bool:
        """非任务期统一 LLM 提问（每回合至多 1 条，受每日额度限制）。"""
        if self._llm_waiting or ctx.prompt or not self._llm_budget_ok(turn):
            return False
        ctx.prompt = prompt
        self.llm_calls_today += 1
        self._llm_waiting = kind
        self._llm_round = turn.round_no
        self.llm_owner = kind      # P0-3：本 prompt 的响应归 news/treasure
        return True

    def _vacate_layout_cell(self, turn: Turn, worker, ctx: _Ctx) -> dict[str, Any] | None:
        """空闲工人站在炮台/控制点上时主动让位（否则该格永远无法建造/归位）。"""
        if self.layout is None:
            return None
        hot = set(self.layout.turret_cells) | {self.layout.control_point}
        if worker.pos not in hot:
            return None
        blocked = turn.blocked(worker)
        cands = [
            pos for pos in worker.pos.neighbours()
            if pos not in hot and turn.land(pos) and pos not in blocked and pos not in ctx.reserved
        ]
        if not cands:
            return None
        station = turn.station()
        anchor = station.pos if station is not None else worker.pos
        cands.sort(key=lambda p: (distance(p, anchor), p.x, p.y))
        ctx.note(worker.unit_id, "vacate_layout_cell")
        return move_command(cands[0])

    # ---- 机器人出生点遥测（FRONT 修正证据，RULE_ASSUMPTIONS U2）----
    def _observe_spawns(self, turn: Turn, ctx: _Ctx) -> None:
        if turn.round_in_day != 70 or not turn.robots:  # 每夜第1回合
            return
        station = turn.station()
        if station is None:
            return
        spawns = [(r.pos.x, r.pos.y) for r in turn.hostile_robots]  # Q6：排除自家召唤
        self.robot_spawn_log.append({"day": turn.day_index, "spawns": spawns})
        # 主来向：相对基地的 dominant axis（累计所有夜晚）；墙环应朝向来向（开口=其反向）
        sx = sum(x for day in self.robot_spawn_log for x, _ in day["spawns"])
        sy = sum(y for day in self.robot_spawn_log for _, y in day["spawns"])
        n = sum(len(day["spawns"]) for day in self.robot_spawn_log)
        cx, cy = station.pos.x + 0.5, station.pos.y - 0.5
        dx, dy = sx / n - cx, sy / n - cy
        observed = ("E" if dx > 0 else "W") if abs(dx) >= abs(dy) else ("N" if dy > 0 else "S")
        opposite = {"W": "E", "E": "W", "N": "S", "S": "N"}
        ctx.trace["robot_approach"] = observed
        walls_facing = opposite[self.front] if self.front else None
        if walls_facing is not None and observed != walls_facing:
            ctx.trace["front_recommendation"] = opposite[observed]  # 重建走证据驱动变更

    # ---- 召回与自救 ----
    def _interior_cells(self, turn: Turn) -> list:
        """基地邻域内圈格（离前线 CP 最远优先）——召回站位/安全锚点。"""
        station = turn.station()
        if station is None or self.layout is None:
            return []
        base = set(station_footprint(station.pos))
        occupied = turn.occupied_cells()
        cp = self.layout.control_point
        cands: list = []
        for cell in base:
            for pos in cell.neighbours():
                if (
                    turn.land(pos)
                    and pos not in base
                    and pos not in occupied
                    and pos not in cands
                ):
                    cands.append(pos)
        cands.sort(key=lambda p: (-distance(p, cp), p.x, p.y))
        return cands

    def _assign_recall_cells(self, turn: Turn) -> dict[int, Any]:
        interior = self._interior_cells(turn)
        return {
            worker.unit_id: interior[index]
            for index, worker in enumerate(turn.workers())
            if index < len(interior)
        }

    def _maybe_medicine(self, turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
        """开拓者低血量且有药时使用（不覆盖已有指令，且本回合未在控炮）。"""
        pioneer = turn.pioneer()
        if pioneer is None or pioneer.unit_id in commands:
            return
        for cmd in commands.values():  # 操控占用：控炮回合不能再用药
            if cmd.get("action") == "attack" and cmd.get("controllerId") == str(pioneer.unit_id):
                return
        if pioneer.health > 300:  # 32进16：HP 200→500，阈值等比例上调（原 120）
            return
        medicine = next(
            (item for item in pioneer.backpack if item.lower() == "medicine"), None
        )
        if medicine is not None:
            commands[pioneer.unit_id] = use_command(medicine)

    def _worker_fsm(self, worker) -> WorkerFSM:
        fsm = self.worker_fsms.get(worker.unit_id)
        if fsm is None:
            fsm = WorkerFSM(worker.unit_id)
            self.worker_fsms[worker.unit_id] = fsm
        return fsm


_BRAIN = Brain()


def decide(payload: dict[str, Any] | None) -> tuple[dict[str, Any], dict[str, Any]]:
    return _BRAIN.decide(payload)
