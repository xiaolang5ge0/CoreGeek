"""L4 WorkerFSM：FSM + Goal Commitment + Task Lock。

主链：ECONOMIC_FREE → 选矿 → MINE_COLLECT_LOCKED → 矿耗尽 → ECONOMIC_FREE
支链：BUILD（白天，brain 分配，优先级最高）
      SELL（仅 FREE 态评估/背包满触发，**绝不抢占采矿锁** —— STRATEGY_DECISIONS #11）
看门狗：连续移动意图但位置未变 → UNSTUCK，清空目标下轮重选（防原地打转）。
CRITICAL_DEFENSE 抢关在 P3 接入。
"""
from __future__ import annotations

from typing import Any

from .path import next_step, step_toward
from .planners.upgrade import WALL_MAX_HP, voucher_for
from .protocol import (
    MINE_TYPES,
    Pos,
    TOWER_TYPES,
    Turn,
    Unit,
    WALL,
    STATION,
    build_command,
    buy_command,
    collect_command,
    distance,
    move_command,
    sell_command,
    use_command,
)

ORE_STONE = "ore_stone"
ORE_MONEY = "ore_money"

STATE_FREE = "ECONOMIC_FREE"
STATE_BUILD = "BUILD"
STATE_MINE_LOCKED = "MINE_COLLECT_LOCKED"
STATE_SELL = "SELL"
STATE_CRITICAL = "CRITICAL_DEFENSE"
STATE_EVADE = "EVADE"
STATE_UPGRADE = "UPGRADE"
STATE_REPAIR = "NIGHT_REPAIR"

EVADE_DIST = 2  # 非眩晕机器人贴近此距离即撤离

# 墙料批量阈值：攒够即去建墙，摊薄往返路费（入夜前紧急时 1 块也建）
STONE_BATCH = 6
DUSK_URGENT_ROUNDS = 12

# 机会性卖货阈值（STRATEGY_DECISIONS #11：看矿点与小贩相对位置）
SELL_NEAR_VENDOR_DIST = 3   # 小贩近在咫尺
SELL_NEAR_MIN_VALUE = 8     # 顺路最低货值（金）
SELL_RICH_MIN_VALUE = 25    # 值得专程跑一趟的货值
SELL_RICH_MAX_DIST = 15     # 专程跑的最大距离

STUCK_LIMIT = 5             # 连续移动意图但位置未变的上限
STUCK_COLLECT_LIMIT = 3     # 连续 collect 但背包不涨 → 矿已空/封矿，解锁拉黑
WORKER_DANGER_DIST = 3      # 机器人贴脸(≤此距离)才规避；脱离 +2 即恢复采矿（与 brain 一致）
MAX_MINE_DIST = 16          # 优先选距我方基地此范围内的矿（避免深入对方侧被兵潮顺路打死）


class WorkerFSM:
    def __init__(self, unit_id: int):
        self.unit_id = unit_id
        self.state = STATE_FREE
        self.ore_role = ORE_MONEY
        self.mine: Pos | None = None
        self.build: tuple[Pos, str] | None = None
        self.sell_vendor: Pos | None = None
        self.upgrade: tuple[Pos, str] | None = None  # (目标建筑格, 种类)
        self._stuck_moves = 0
        self._stuck_collects = 0
        self._last_pos: Pos | None = None
        self._last_bag = -1
        self._evading = False  # 夜间危险规避中（滞回：≤3进 ≥5退），脱离即恢复采矿
        self.build_phase = False  # 采够一批后连续建墙模式（防采一建一）

    # ---- 主入口 ----
    def decide(self, turn: Turn, unit: Unit, ctx) -> dict[str, Any] | None:
        if turn.is_day:
            self._evading = False  # 天亮解除规避
        if unit.pos != self._last_pos:
            self._stuck_moves = 0
        if len(unit.backpack) != self._last_bag:
            self._stuck_collects = 0
        self._last_pos = unit.pos
        self._last_bag = len(unit.backpack)
        cmd = self._decide(turn, unit, ctx)
        # upgrade 目标可能是 Pos（建筑升级）或 str（stock 备货券名），分别序列化
        if self.upgrade:
            up_target = self.upgrade[0]
            up_dump = up_target.dump() if hasattr(up_target, "dump") else up_target
            up_repr = [up_dump, self.upgrade[1]]
        else:
            up_repr = None
        ctx.trace["workers"][str(self.unit_id)] = {
            "state": self.state,
            "ore_role": self.ore_role,
            "mine": self.mine.dump() if self.mine else None,
            "build": [self.build[0].dump(), self.build[1]] if self.build else None,
            "sell": self.sell_vendor.dump() if self.sell_vendor else None,
            "upgrade": up_repr,
            "cmd": cmd.get("action") if cmd else None,
        }
        return cmd

    def _decide(self, turn: Turn, unit: Unit, ctx) -> dict[str, Any] | None:
        # 修墙岗（Day4+/重伤夜固定 ID 最小工人）：仅在确有墙需修时值守，否则照常采矿
        is_repair = turn.is_night and getattr(ctx, "repair_worker", None) == self.unit_id
        # 0a. 夜间危险规避（滞回，非粘性）：机器人贴脸(≤3)才规避，脱离(≥5)即恢复采矿。
        #     事实：机器人主攻基地、顺路才杀工人 → 不必整夜蹲防，夜1 可全力采矿。
        if turn.is_night and not is_repair:
            nearest = min(
                (distance(unit.pos, r.pos) for r in turn.robots
                 if r.alive and r.target_team in ("", turn.team_type)),
                default=99,
            )
            if nearest <= WORKER_DANGER_DIST:
                self._evading = True
            elif nearest >= WORKER_DANGER_DIST + 2:
                self._evading = False
            if self._evading:
                cell = getattr(ctx, "safe_anchor", None) or ctx.recall_cell(self.unit_id)
                if cell is not None and unit.pos != cell:
                    self.mine = None
                    self.build = None
                    self.sell_vendor = None
                    self.state = STATE_CRITICAL
                    step = next_step(turn, unit, cell, ctx.reserved)
                    if step is not None:
                        return self._move(step, ctx)
                self.state = STATE_CRITICAL
                return None  # 危险未解除，暂避内圈
        # 0c. 夜间修墙岗：有墙需修且持有物料 → 就地修复；否则落到采矿逻辑（不空蹲）
        if is_repair:
            cmd = self._repair_cmd(turn, unit, ctx)
            if cmd is not None:
                return cmd
        # 1. 建造任务（白天，优先级最高）
        if self.build is not None:
            if turn.is_night:
                self.build = None
            else:
                self.state = STATE_BUILD
                return self._build_cmd(turn, unit, ctx)
        # 1b. 升级任务（仅白天；夜间挂起，次日自动继续）
        if self.upgrade is not None and turn.is_day:
            self.state = STATE_UPGRADE
            return self._upgrade_cmd(turn, unit, ctx)
        # 2. 背包满 → 卖矿（解除矿锁，卖完重选，可能回到同一矿）
        if unit.backpack_full:
            if self.mine is not None:
                ctx.note(self.unit_id, "release_lock_backpack_full")
                self.mine = None
            return self._sell_chain(turn, unit, ctx, mandatory=True)
        # 3. 采矿锁（SELL 不得抢占 —— 采完再走）
        if self.mine is not None:
            if self.mine not in turn.mines():
                ctx.note(self.unit_id, "mine_depleted")
                self.mine = None
            elif ctx.is_mine_blocked(self.mine, turn.round_no):
                ctx.note(self.unit_id, "mine_blocked_news")
                self.mine = None
            else:
                self.state = STATE_MINE_LOCKED
                cmd = self._mine_cmd(turn, unit, ctx)
                if cmd is not None:
                    return cmd
                ctx.note(self.unit_id, "mine_unreachable")
                self.mine = None
        # 4. FREE 态：机会性卖货评估
        self.state = STATE_FREE
        if self._should_sell(turn, unit, ctx):
            return self._sell_chain(turn, unit, ctx, mandatory=False)
        # 5. 选矿
        self.mine = self._select_mine(turn, unit, ctx)
        if self.mine is None:
            ctx.note(self.unit_id, "no_mine")
            return None
        self.state = STATE_MINE_LOCKED
        return self._mine_cmd(turn, unit, ctx)

    # ---- 建造 ----
    def _build_cmd(self, turn: Turn, unit: Unit, ctx) -> dict[str, Any] | None:
        cell, name = self.build
        if unit.pos != cell and distance(unit.pos, cell) <= 1:
            self.build = None
            self.state = STATE_FREE
            return build_command(cell, name)
        step = step_toward(turn, unit, cell, ctx.reserved)
        if step is not None:
            return self._move(step, ctx)
        ctx.note(self.unit_id, "build_unreachable")
        self.build = None
        self.state = STATE_FREE
        return None

    # ---- 升级任务链：走到商店买券 → 走到目标建筑用券 ----
    def _upgrade_cmd(self, turn: Turn, unit: Unit, ctx) -> dict[str, Any] | None:
        target, kind = self.upgrade
        if kind == "stock":
            # 备货任务：买到手即完成（WallFixer 等，供夜间修墙岗使用）
            item = target if isinstance(target, str) else "WallFixer"
            if item in unit.backpack:
                self.upgrade = None
                self.state = STATE_FREE
                return None
            shop = self._nearest_shop(turn, unit)
            if shop is None or turn.gold < 10:
                self.upgrade = None
                self.state = STATE_FREE
                return None
            if unit.pos != shop and distance(unit.pos, shop) <= 1:
                self.upgrade = None
                self.state = STATE_FREE
                return buy_command(item)
            step = step_toward(turn, unit, shop, ctx.reserved)
            if step is None:
                self.upgrade = None
                self.state = STATE_FREE
                return None
            return self._move(step, ctx)
        building = next(
            (u for u in turn.ours if u.pos == target and u.kind in (*TOWER_TYPES, WALL, STATION)),
            None,
        )
        if building is None or building.level >= 3:
            ctx.note(self.unit_id, "upgrade_target_gone")
            self.upgrade = None
            self.state = STATE_FREE
            return None
        entry = voucher_for(kind, building.level)
        if entry is None:
            self.upgrade = None
            self.state = STATE_FREE
            return None
        voucher, cost = entry
        if voucher not in unit.backpack:
            if turn.gold < cost:
                ctx.note(self.unit_id, "upgrade_gold_short")
                self.upgrade = None
                self.state = STATE_FREE
                return None
            shop = self._nearest_shop(turn, unit)
            if shop is None:
                ctx.note(self.unit_id, "no_shop")
                self.upgrade = None
                self.state = STATE_FREE
                return None
            if unit.pos != shop and distance(unit.pos, shop) <= 1:
                return buy_command(voucher)
            step = step_toward(turn, unit, shop, ctx.reserved)
            if step is None:
                ctx.note(self.unit_id, "shop_unreachable")
                self.upgrade = None
                self.state = STATE_FREE
                return None
            return self._move(step, ctx)
        # 券已入手 → 走到目标旁使用
        if unit.pos != target and distance(unit.pos, target) <= 1:
            self.upgrade = None
            self.state = STATE_FREE
            return use_command(voucher, target)
        step = step_toward(turn, unit, target, ctx.reserved)
        if step is None:
            ctx.note(self.unit_id, "upgrade_target_unreachable")
            self.upgrade = None
            self.state = STATE_FREE
            return None
        return self._move(step, ctx)

    def _nearest_shop(self, turn: Turn, unit: Unit) -> Pos | None:
        shops = turn.shop_positions()
        if not shops:
            return None
        return min(shops, key=lambda s: (distance(unit.pos, s), s.x, s.y))

    # ---- 夜间修墙岗 ----
    def _repair_cmd(self, turn: Turn, unit: Unit, ctx) -> dict[str, Any] | None:
        self.state = STATE_REPAIR
        walls = list(turn.walls())
        item = target = None
        if walls:
            def ratio(w):
                return w.health / WALL_MAX_HP[min(max(w.level, 1), 3) - 1]
            hurt = [w for w in walls if ratio(w) < 0.999]
            if hurt:
                hurt.sort(key=ratio)
                target = hurt[0].pos
                lv = hurt[0].level
                voucher = f"WallUpgradeVoucher{lv}"
                if lv <= 2 and voucher in unit.backpack:
                    item = voucher
                elif "WallFixer" in unit.backpack:
                    item = "WallFixer"
        if item is not None and target is not None:
            if unit.pos != target and distance(unit.pos, target) <= 1:
                return use_command(item, target)
            step = step_toward(turn, unit, target, ctx.reserved)
            if step is not None:
                return self._move(step, ctx)
        # 无修复需求/无物料 → 返回 None，落回采矿逻辑（不空蹲内圈）
        return None

    # ---- 采矿 ----
    def _mine_cmd(self, turn: Turn, unit: Unit, ctx) -> dict[str, Any] | None:
        # 锁定矿进入机器人危险圈/出生走廊（夜间或临近入夜）→ 放弃
        if ctx.dusk_avoid and ctx.mine_unsafe(self.mine):
            ctx.note(self.unit_id, "mine_unsafe_release")
            self.mine = None
            self.state = STATE_FREE
            return None
        # 锁定矿距我方基地超出近矿半径 → 释放（实战：跑远侧矿区被兵潮顺路打死）
        station = turn.station()
        if station is not None and distance(station.pos, self.mine) > MAX_MINE_DIST:
            ctx.note(self.unit_id, "mine_too_far_release")
            self.mine = None
            self.state = STATE_FREE
            return None
        if unit.pos != self.mine and distance(unit.pos, self.mine) <= 1:
            cmd = collect_command(self.mine)
            # 采集死循环看门狗：连续 collect 但背包不涨（矿已空/封矿）→ 解锁+拉黑
            self._stuck_collects += 1
            if self._stuck_collects >= STUCK_COLLECT_LIMIT:
                self._stuck_collects = 0
                ctx.note(self.unit_id, "collect_stuck_release")
                ctx.block_mine(self.mine, turn.round_no + 20)
                self.mine = None
                self.state = STATE_FREE
                return None
            return cmd
        self._stuck_collects = 0
        step = step_toward(turn, unit, self.mine, ctx.reserved)
        if step is None:
            return None
        return self._move(step, ctx)

    def _select_mine(self, turn: Turn, unit: Unit, ctx) -> Pos | None:
        other_locks = () if ctx.share_mines else ctx.other_mine_locks(self.unit_id)
        station = turn.station()
        enemy_station = next((u for u in turn.enemy if u.kind == "station"), None)
        # 两遍：先在我方基地 MAX_MINE_DIST 内的矿中选；没有才放宽（避免舍近求远深入对方侧）
        valid: list[tuple[Pos, str, int, int]] = []
        for pos in turn.mines():
            if pos in other_locks:
                continue
            if ctx.is_mine_blocked(pos, turn.round_no):
                continue
            if ctx.dusk_avoid and ctx.mine_unsafe(pos):
                continue
            kind = turn.zones.get(pos)
            if self.ore_role == ORE_STONE and kind != "stone":
                continue
            if self.ore_role == ORE_MONEY and kind == "stone" and ctx.walls_missing:
                continue
            our_dist = distance(station.pos, pos) if station is not None else distance(unit.pos, pos)
            valid.append((pos, kind, distance(unit.pos, pos), our_dist))
        if not valid:
            return None
        near = [m for m in valid if m[3] <= MAX_MINE_DIST]
        if near:
            pool = near
        else:
            # 无近矿：只接受"离我方基地不更远"的矿；敌方侧矿一律不选（宁可空闲等刷新，也不深入送死）
            pool = [
                m for m in valid
                if enemy_station is None
                or distance(enemy_station.pos, m[0]) >= m[3]
            ]
        if not pool:
            return None
        best: Pos | None = None
        best_key = None
        for pos, kind, dist, our_dist in pool:
            side_penalty = 0.0
            if enemy_station is not None and distance(enemy_station.pos, pos) < our_dist:
                side_penalty = 12.0  # 该矿离敌方基地更近 → 对方侧
            if self.ore_role == ORE_STONE:
                key = (dist + our_dist * 0.6 + side_penalty, dist, pos.x, pos.y)
            else:
                price = turn.vendor_prices.get(kind, 1)
                key = (dist - price * 10 + our_dist * 0.6 + side_penalty, dist, pos.x, pos.y)
            if best is None or key < best_key:
                best, best_key = pos, key
        return best

    # ---- 卖货 ----
    def _sell_chain(
        self, turn: Turn, unit: Unit, ctx, *, mandatory: bool
    ) -> dict[str, Any] | None:
        vendor = self._nearest_vendor(turn, unit)
        if vendor is None:
            ctx.note(self.unit_id, "no_vendor")
            return None
        self.sell_vendor = vendor
        if unit.pos != vendor and distance(unit.pos, vendor) <= 1:
            cmd = self._sell_best(turn, unit, ctx)
            if cmd is None:
                self.sell_vendor = None
                self.state = STATE_FREE
                return None
            self.state = STATE_SELL
            return cmd
        if mandatory is False and self.state != STATE_SELL:
            self.state = STATE_FREE  # 尚未出发，保持 FREE 语义
        step = step_toward(turn, unit, vendor, ctx.reserved)
        if step is None:
            ctx.note(self.unit_id, "vendor_unreachable")
            return None
        self.state = STATE_SELL
        return self._move(step, ctx)

    def _sell_best(self, turn: Turn, unit: Unit, ctx) -> dict[str, Any] | None:
        """单次只能卖一种矿：选 数量×单价 最高的种类批量卖。"""
        best: tuple[int, str] | None = None
        for ore in MINE_TYPES:
            if ore == "stone" and ctx.walls_missing:
                continue  # 墙料不外流
            count = unit.backpack.count(ore)
            if count == 0:
                continue
            value = count * turn.vendor_prices.get(ore, 1)
            if best is None or value > best[0]:
                best = (value, ore)
        if best is None:
            return None
        _, ore = best
        return sell_command(ore, unit.backpack.count(ore))

    def _should_sell(self, turn: Turn, unit: Unit, ctx) -> bool:
        value = self._sellable_value(turn, unit, ctx)
        if value <= 0:
            return False
        vendor = self._nearest_vendor(turn, unit)
        if vendor is None:
            return False
        # 卖货安全：夜间或临近入夜时，小贩在机器人/出生走廊危险圈内则不去（小贩居地图心=兵潮走廊）
        if ctx.dusk_avoid and ctx.mine_unsafe(vendor):
            return False
        if ctx.need_gold:
            return True  # 急用金（重建武器等）
        dist = distance(unit.pos, vendor)
        if dist <= SELL_NEAR_VENDOR_DIST and value >= SELL_NEAR_MIN_VALUE:
            return True  # 顺路
        if value >= SELL_RICH_MIN_VALUE and dist <= SELL_RICH_MAX_DIST:
            return True  # 值得专程
        return False

    def _sellable_value(self, turn: Turn, unit: Unit, ctx) -> int:
        value = 0
        for ore in MINE_TYPES:
            if ore == "stone" and ctx.walls_missing:
                continue
            value += unit.backpack.count(ore) * turn.vendor_prices.get(ore, 1)
        return value

    def _nearest_vendor(self, turn: Turn, unit: Unit) -> Pos | None:
        vendors = turn.vendor_positions()
        if not vendors:
            return None
        return min(vendors, key=lambda v: (distance(unit.pos, v), v.x, v.y))

    # ---- 看门狗 ----
    def _move(self, step: Pos, ctx) -> dict[str, Any] | None:
        self._stuck_moves += 1
        if self._stuck_moves >= STUCK_LIMIT:
            self._stuck_moves = 0
            ctx.note(self.unit_id, "unstuck")
            self.mine = None
            self.build = None
            self.sell_vendor = None
            self.state = STATE_FREE
            return None
        return move_command(step)
